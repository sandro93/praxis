import System
import Data.Char
import System.IO
import Data.List
main = do
 x <- readLn
 y <- readLn
 print( x + y)

