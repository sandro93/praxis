bothTrue ::Bool -> Bool -> Bool
bothTrue a b = min a b